ipykernel.inprocess package
===========================

Submodules
----------


.. automodule:: ipykernel.inprocess.blocking
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: ipykernel.inprocess.channels
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: ipykernel.inprocess.client
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: ipykernel.inprocess.constants
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: ipykernel.inprocess.ipkernel
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: ipykernel.inprocess.manager
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: ipykernel.inprocess.socket
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ipykernel.inprocess
   :members:
   :undoc-members:
   :show-inheritance:
